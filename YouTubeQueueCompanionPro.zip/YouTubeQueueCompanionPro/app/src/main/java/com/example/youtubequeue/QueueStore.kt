package com.example.youtubequeue

import android.content.Context
import org.json.JSONArray

class QueueStore(context: Context) {
    private val prefs = context.getSharedPreferences("queue", Context.MODE_PRIVATE)
    private val key = "items"

    fun items(): MutableList<String> {
        val a = JSONArray(prefs.getString(key, "[]"))
        return MutableList(a.length()) { i -> a.getString(i) }
    }

    fun add(raw: String): Boolean {
        val url = extractYouTubeUrl(raw) ?: return false
        val x = items()
        if (!x.contains(url)) { x.add(url); save(x) }
        return true
    }

    fun remove(index: Int) {
        val x = items()
        if (index in x.indices) { x.removeAt(index); save(x) }
    }

    fun move(from: Int, to: Int) {
        val x = items()
        if (from !in x.indices || to !in x.indices || from == to) return
        val v = x.removeAt(from); x.add(to, v); save(x)
    }

    fun pop(): String? {
        val x = items()
        if (x.isEmpty()) return null
        val v = x.removeAt(0); save(x); return v
    }

    fun clear() = save(emptyList())

    private fun save(x: List<String>) {
        prefs.edit().putString(key, JSONArray(x).toString()).apply()
    }

    private fun extractYouTubeUrl(raw: String): String? {
        val candidate = raw.trim().split("\s+".toRegex()).firstOrNull { it.contains("youtu") } ?: return null
        return if (candidate.startsWith("https://www.youtube.com/") ||
            candidate.startsWith("https://youtube.com/") ||
            candidate.startsWith("https://youtu.be/") ||
            candidate.startsWith("http://www.youtube.com/") ||
            candidate.startsWith("http://youtube.com/") ||
            candidate.startsWith("http://youtu.be/")) candidate else null
    }
}