package com.example.youtubequeue

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var store: QueueStore
    private lateinit var list: LinearLayout
    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = QueueStore(this)
        buildUi()
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    private fun handleIncoming(intent: Intent?) {
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT) ?: return
        if (store.add(text)) Toast.makeText(this, "Added to queue", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
        }
        val title = TextView(this).apply { text = "YouTube Queue Pro"; textSize = 28f }
        count = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 18) }
        val help = TextView(this).apply {
            text = "Share any YouTube video to this app. Enable Accessibility below so the app can detect an ended video and open the next item."
            textSize = 15f
        }
        val input = EditText(this).apply { hint = "Paste YouTube link"; setSingleLine(true) }
        val add = Button(this).apply {
            text = "Add to queue"
            setOnClickListener {
                if (store.add(input.text.toString())) {
                    input.setText("")
                    Toast.makeText(this@MainActivity, "Added", Toast.LENGTH_SHORT).show()
                    refresh()
                } else Toast.makeText(this@MainActivity, "Please enter a YouTube link", Toast.LENGTH_SHORT).show()
            }
        }
        val settings = Button(this).apply {
            text = "Enable automatic next video"
            setOnClickListener { startActivity(Intent("android.settings.ACCESSIBILITY_SETTINGS")) }
        }
        val clear = Button(this).apply {
            text = "Clear queue"
            setOnClickListener { store.clear(); refresh() }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.addView(title); root.addView(count); root.addView(help)
        root.addView(input); root.addView(add); root.addView(settings); root.addView(clear)
        root.addView(list)
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val items = store.items()
        count.text = "${items.size} video${if (items.size == 1) "" else "s"} queued"
        items.forEachIndexed { i, url ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 5, 0, 5) }
            val number = TextView(this).apply { text = "${i + 1}  "; textSize = 15f }
            val label = TextView(this).apply {
                text = friendly(url); textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val up = Button(this).apply { text = "↑"; isEnabled = i > 0; setOnClickListener { store.move(i, i-1); refresh() } }
            val down = Button(this).apply { text = "↓"; isEnabled = i < items.lastIndex; setOnClickListener { store.move(i, i+1); refresh() } }
            val open = Button(this).apply {
                text = "▶"; setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
            val del = Button(this).apply { text = "✕"; setOnClickListener { store.remove(i); refresh() } }
            row.addView(number); row.addView(label); row.addView(up); row.addView(down); row.addView(open); row.addView(del)
            list.addView(row)
        }
    }

    private fun friendly(url: String): String {
        return try {
            val u = Uri.parse(url)
            u.getQueryParameter("v") ?: u.lastPathSegment ?: url
        } catch (_: Exception) { url }
    }
}