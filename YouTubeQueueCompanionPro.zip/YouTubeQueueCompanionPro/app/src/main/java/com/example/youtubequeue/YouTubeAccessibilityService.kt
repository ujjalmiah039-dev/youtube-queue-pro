package com.example.youtubequeue

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.view.accessibility.AccessibilityNodeInfo

class YouTubeAccessibilityService : AccessibilityService() {
    private var endedLatched = false
    private var lastLaunchAt = 0L

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.google.android.youtube") return
        val root = rootInActiveWindow ?: return
        val text = collect(root).joinToString(" ").lowercase()

        // Conservative detection: require multiple end-state signals before advancing.
        val replay = text.contains("replay") || text.contains("watch again")
        val ended = text.contains("video ended") || text.contains("up next") && text.contains("replay")
        val endState = replay || ended

        if (!endState) {
            endedLatched = false
            return
        }
        val now = System.currentTimeMillis()
        if (endedLatched || now - lastLaunchAt < 7000) return

        val next = QueueStore(this).pop() ?: return
        endedLatched = true
        lastLaunchAt = now
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(next)).apply {
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) }
        catch (_: Exception) {
            intent.setPackage(null)
            startActivity(intent)
        }
    }

    private fun collect(n: AccessibilityNodeInfo): List<String> {
        val out = mutableListOf<String>()
        n.text?.let { out.add(it.toString()) }
        n.contentDescription?.let { out.add(it.toString()) }
        for (i in 0 until n.childCount) n.getChild(i)?.let { out.addAll(collect(it)) }
        return out
    }

    override fun onInterrupt() {}
}